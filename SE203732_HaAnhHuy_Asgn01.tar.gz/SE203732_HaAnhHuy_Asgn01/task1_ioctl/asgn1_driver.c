#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>
#include <linux/string.h>
#include <linux/slab.h>

#include "asgn1_ioctl.h"

#define DEVICE_NAME "asgn1"
#define MAJOR_NUM 241
#define BUFFER_SIZE 1024

static char driver_buffer[BUFFER_SIZE];

static int buffer_len;
static int open_count;
static int write_count;
static int read_count;
static int last_write_size;

static int driver_mode = 1;

static DEFINE_MUTEX(driver_mutex);

static const char driver_version[] =
    "asgn1_driver v1.0 - MSSV";

/*
 * Purpose:
 *     Open the ASGN1 character device and increase open_count.
 *
 * Parameters:
 *     inode - inode structure of the device.
 *     file  - file structure associated with the opened device.
 *
 * Return:
 *     0 on success.
 */
static int asgn1_open(struct inode *inode, struct file *file)
{
    mutex_lock(&driver_mutex);

    open_count++;

    mutex_unlock(&driver_mutex);

    printk(KERN_INFO "asgn1: device opened\n");

    return 0;
}

/*
 * Purpose:
 *     Release the ASGN1 character device.
 *
 * Parameters:
 *     inode - inode structure of the device.
 *     file  - file structure associated with the opened device.
 *
 * Return:
 *     0 on success.
 */
static int asgn1_release(struct inode *inode, struct file *file)
{
    printk(KERN_INFO "asgn1: device released\n");

    return 0;
}

/*
 * Purpose:
 *     Read data from the driver's internal buffer to user space.
 *
 * Parameters:
 *     file         - file structure associated with the device.
 *     user_buffer  - user-space buffer receiving the data.
 *     count        - maximum number of bytes to read.
 *     ppos         - current read position.
 *
 * Return:
 *     Number of bytes successfully read, 0 at end of buffer,
 *     or a negative error code on failure.
 */
static ssize_t asgn1_read(
    struct file *file,
    char __user *user_buffer,
    size_t count,
    loff_t *ppos)
{
    size_t bytes_to_copy;

    mutex_lock(&driver_mutex);

    if (*ppos >= buffer_len) {
        mutex_unlock(&driver_mutex);
        return 0;
    }

    bytes_to_copy = min(count, (size_t)(buffer_len - *ppos));

    if (copy_to_user(
            user_buffer,
            driver_buffer + *ppos,
            bytes_to_copy)) {

        mutex_unlock(&driver_mutex);
        return -EFAULT;
    }

    *ppos += bytes_to_copy;
    read_count++;

    mutex_unlock(&driver_mutex);

    return bytes_to_copy;
}

/*
 * Purpose:
 *     Write user data into the driver's internal buffer.
 *     In Kernel mode, prepend the "[KERNEL] " prefix.
 *
 * Parameters:
 *     file         - file structure associated with the device.
 *     user_buffer  - user-space buffer containing the data to write.
 *     count        - number of bytes requested to be written.
 *     ppos         - current write position.
 *
 * Return:
 *     Number of bytes requested to be written on success,
 *     or -EFAULT if copying data from user space fails.
 */
static ssize_t asgn1_write(
    struct file *file,
    const char __user *user_buffer,
    size_t count,
    loff_t *ppos)
{
    size_t data_len;

    mutex_lock(&driver_mutex);

    data_len = min(count, (size_t)(BUFFER_SIZE - 1));

    memset(driver_buffer, 0, BUFFER_SIZE);

    if (driver_mode == 0) {
        const char prefix[] = "[KERNEL] ";
        size_t prefix_len = strlen(prefix);

        if (prefix_len + data_len >= BUFFER_SIZE) {
            data_len = BUFFER_SIZE - prefix_len - 1;
        }

        memcpy(driver_buffer, prefix, prefix_len);

        if (copy_from_user(
                driver_buffer + prefix_len,
                user_buffer,
                data_len)) {

            mutex_unlock(&driver_mutex);
            return -EFAULT;
        }

        buffer_len = prefix_len + data_len;
    }
    else {
        if (copy_from_user(
                driver_buffer,
                user_buffer,
                data_len)) {

            mutex_unlock(&driver_mutex);
            return -EFAULT;
        }

        buffer_len = data_len;
    }

    last_write_size = count;
    write_count++;

    mutex_unlock(&driver_mutex);

    return count;
}
/*
 * Purpose:
 *     Handle ioctl commands for resetting the buffer, getting driver
 *     statistics, setting the driver mode, and getting the driver version.
 *
 * Parameters:
 *     file - file structure associated with the device.
 *     cmd  - ioctl command requested by user space.
 *     arg  - argument passed between user space and kernel space.
 *
 * Return:
 *     0 on success, or a negative error code on failure.
 */         
static long asgn1_ioctl(
    struct file *file,
    unsigned int cmd,
    unsigned long arg)
{
    struct asgn1_stats stats;
    int mode;
    char version[64];

    switch (cmd) {

    case ASGN1_RESET_BUFFER:

        printk(KERN_INFO
               "asgn1: ASGN1_RESET_BUFFER called\n");

        mutex_lock(&driver_mutex);

        memset(driver_buffer, 0, BUFFER_SIZE);

        buffer_len = 0;
        write_count = 0;
        read_count = 0;
        last_write_size = 0;

        mutex_unlock(&driver_mutex);

        return 0;


    case ASGN1_GET_STATS:

        printk(KERN_INFO
               "asgn1: ASGN1_GET_STATS called\n");

        mutex_lock(&driver_mutex);

        stats.open_count = open_count;
        stats.write_count = write_count;
        stats.read_count = read_count;
        stats.buffer_len = buffer_len;
        stats.last_write_size = last_write_size;

        mutex_unlock(&driver_mutex);

        if (copy_to_user(
                (struct asgn1_stats __user *)arg,
                &stats,
                sizeof(stats))) {

            return -EFAULT;
        }

        return 0;


    case ASGN1_SET_MODE:

        printk(KERN_INFO
               "asgn1: ASGN1_SET_MODE called\n");

        if (copy_from_user(
                &mode,
                (int __user *)arg,
                sizeof(mode))) {

            return -EFAULT;
        }

        if (mode != 0 && mode != 1)
            return -EINVAL;

        mutex_lock(&driver_mutex);

        driver_mode = mode;

        mutex_unlock(&driver_mutex);

        return 0;


    case ASGN1_GET_VERSION:

        printk(KERN_INFO
               "asgn1: ASGN1_GET_VERSION called\n");

        memset(version, 0, sizeof(version));

        strncpy(
            version,
            driver_version,
            sizeof(version) - 1);

        if (copy_to_user(
                (char __user *)arg,
                version,
                sizeof(version))) {

            return -EFAULT;
        }

        return 0;


    default:

        printk(KERN_WARNING
               "asgn1: invalid ioctl command\n");

        return -ENOTTY;
    }
}

static struct file_operations asgn1_fops = {
    .owner = THIS_MODULE,
    .open = asgn1_open,
    .release = asgn1_release,
    .read = asgn1_read,
    .write = asgn1_write,
    .unlocked_ioctl = asgn1_ioctl,
};


static int __init asgn1_init(void)
{
    int ret;

    ret = register_chrdev(
        MAJOR_NUM,
        DEVICE_NAME,
        &asgn1_fops);

    if (ret < 0) {
        printk(KERN_ERR
               "asgn1: register_chrdev failed\n");

        return ret;
    }

    memset(driver_buffer, 0, BUFFER_SIZE);

    buffer_len = 0;
    open_count = 0;
    write_count = 0;
    read_count = 0;
    last_write_size = 0;

    driver_mode = 1;

    printk(KERN_INFO
           "asgn1: driver loaded, major=%d\n",
           MAJOR_NUM);

    return 0;
}


static void __exit asgn1_exit(void)
{
    unregister_chrdev(
        MAJOR_NUM,
        DEVICE_NAME);

    printk(KERN_INFO
           "asgn1: driver unloaded\n");
}

module_init(asgn1_init);
module_exit(asgn1_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("HaAnhHuy - SE203732");
MODULE_DESCRIPTION(
    "Assignment 01 ioctl character device driver");
