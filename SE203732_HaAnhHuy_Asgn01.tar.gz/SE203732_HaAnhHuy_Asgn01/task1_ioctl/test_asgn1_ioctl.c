#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <errno.h>

#include "asgn1_ioctl.h"

#define DEVICE "/dev/asgn1"

static void print_stats(int fd)
{
    struct asgn1_stats stats;

    memset(&stats, 0, sizeof(stats));

    if (ioctl(fd, ASGN1_GET_STATS, &stats) < 0) {
        perror("ASGN1_GET_STATS");
        return;
    }

    printf("STATS:\n");
    printf("  open_count      = %d\n", stats.open_count);
    printf("  write_count     = %d\n", stats.write_count);
    printf("  read_count      = %d\n", stats.read_count);
    printf("  buffer_len      = %d\n", stats.buffer_len);
    printf("  last_write_size = %d\n", stats.last_write_size);
}

static void read_buffer()
{
    int fd;
    char buffer[1024];
    ssize_t n;

    memset(buffer, 0, sizeof(buffer));

    fd = open(DEVICE, O_RDONLY);

    if (fd < 0) {
        perror("open " DEVICE);
        return;
    }

    n = read(fd, buffer, sizeof(buffer) - 1);

    if (n < 0) {
        perror("read");
        close(fd);
        return;
    }

    buffer[n] = '\0';

    printf("READ [%zd bytes]: \"%s\"\n", n, buffer);

    close(fd);
}
int main(void)
{
    int fd;
    int mode;
    char version[64];

    printf("=== ASGN1 IOCTL TEST ===\n");

    fd = open(DEVICE, O_RDWR);

    if (fd < 0) {
        perror("open " DEVICE);
        return 1;
    }

    printf("\n[1] GET_VERSION\n");

    memset(version, 0, sizeof(version));

    if (ioctl(fd, ASGN1_GET_VERSION, version) < 0) {
        perror("ASGN1_GET_VERSION");
    } else {
        printf("VERSION: \"%s\"\n", version);
    }

    printf("\n[2] SET_MODE = 1 (Echo mode)\n");

    mode = 1;

    if (ioctl(fd, ASGN1_SET_MODE, &mode) < 0) {
        perror("ASGN1_SET_MODE");
    } else {
        const char *msg = "Hello Echo Mode";

        if (write(fd, msg, strlen(msg)) < 0) {
            perror("write");
        } else {
            printf("WRITE: \"%s\"\n", msg);
        }

        read_buffer();
    }

    printf("\n[3] SET_MODE = 0 (Kernel mode)\n");

    mode = 0;

    if (ioctl(fd, ASGN1_SET_MODE, &mode) < 0) {
        perror("ASGN1_SET_MODE");
    } else {
        const char *msg = "Hello Kernel Mode";

        if (write(fd, msg, strlen(msg)) < 0) {
            perror("write");
        } else {
            printf("WRITE: \"%s\"\n", msg);
        }

        read_buffer();
    }

    printf("\n[4] GET_STATS\n");
    print_stats(fd);

    printf("\n[5] RESET_BUFFER\n");

/* Write data before reset */
const char *reset_test_data = "Data before reset";
printf("WRITE before RESET: \"%s\"\n", reset_test_data);

if (write(fd, reset_test_data, strlen(reset_test_data)) < 0) {
    perror("write before RESET");
} else {
    printf("WRITE before RESET: success\n");
}

/* Reset buffer */
if (ioctl(fd, ASGN1_RESET_BUFFER) < 0) {
    perror("ASGN1_RESET_BUFFER");
} else {
    printf("RESET: success\n");
}

/* Read after reset - must be empty */
printf("READ after RESET:\n");
read_buffer();

printf("\n[6] GET_STATS after RESET\n");
print_stats(fd);

    printf("\n[7] Invalid ioctl\n");

    if (ioctl(fd, _IO(ASGN1_MAGIC, 99)) < 0) {
        printf("Invalid ioctl correctly returned error: %s\n",
               strerror(errno));
    } else {
        printf("ERROR: invalid ioctl was accepted!\n");
    }

    close(fd);

    printf("\n=== TEST COMPLETE ===\n");

    return 0;
}
